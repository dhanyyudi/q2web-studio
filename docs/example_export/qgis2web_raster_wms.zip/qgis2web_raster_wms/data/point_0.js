var json_point_0 = {"type":"FeatureCollection","name":"Point Sample","features":[{"type":"Feature","properties":{"NAME":"Sample"},"geometry":{"type":"Point","coordinates":[108.47,-6.79]}}]};
