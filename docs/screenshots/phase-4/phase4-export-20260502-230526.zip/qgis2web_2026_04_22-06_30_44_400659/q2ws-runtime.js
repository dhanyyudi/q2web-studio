(function () {
  // Runtime overlays configuration onto the original qgis2web export.
  // It intentionally depends on globals created by the preserved index.html,
  // especially window.map and window.layer_* variables.
  function ready(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  function createEl(tag, attrs, text) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      el.setAttribute(key, attrs[key]);
    });
    if (text) el.textContent = text;
    return el;
  }

  function styleFor(layerConfig, feature) {
    var style = layerConfig.style || {};
    var field = style.categoryField;
    var category = null;
    if (field && feature && feature.properties) {
      var value = String(feature.properties[field] || "");
      category = (style.categories || []).find(function (item) {
        return item.value === value && item.visible !== false;
      });
    }
    return {
      color: (category && category.strokeColor) || style.strokeColor || "#3388ff",
      fillColor: (category && category.fillColor) || style.fillColor || "#3388ff",
      fillOpacity: Number(style.fillOpacity == null ? 0.5 : style.fillOpacity),
      opacity: Number(style.strokeOpacity == null ? 1 : style.strokeOpacity),
      weight: Number(style.strokeWidth == null ? 2 : style.strokeWidth),
      dashArray: style.dashArray || null,
      radius: Number(style.pointRadius == null ? 6 : style.pointRadius)
    };
  }

  function applyLayerConfig(config) {
    (config.layers || []).forEach(function (layerConfig) {
      var layer = window[layerConfig.layerVariable];
      if (!layer && layerConfig.geojson && window.L) {
        layer = window.L.geoJSON(layerConfig.geojson, {
          style: function (feature) {
            return styleFor(layerConfig, feature);
          },
          pointToLayer: function (feature, latlng) {
            var style = styleFor(layerConfig, feature);
            return window.L.circleMarker(latlng, style);
          }
        });
        window[layerConfig.layerVariable] = layer;
      }
      if (!layer) return;
      if (layer.setStyle) {
        layer.setStyle(function (feature) {
          return styleFor(layerConfig, feature);
        });
      }
      applyLayerPopupAndLabels(layer, layerConfig);
      if (window.map) {
        if (layerConfig.visible === false && window.map.hasLayer(layer)) {
          window.map.removeLayer(layer);
        }
        if (layerConfig.visible !== false && !window.map.hasLayer(layer)) {
          window.map.addLayer(layer);
        }
      }
    });
  }

  function applyLayerPopupAndLabels(layer, layerConfig) {
    if (!layer || !layer.eachLayer) return;
    layer.eachLayer(function (featureLayer) {
      var feature = featureLayer.feature;
      if (!feature) return;
      if (featureLayer.unbindPopup && layerConfig.popupTemplate) {
        featureLayer.unbindPopup();
        if (layerConfig.popupEnabled !== false) {
          featureLayer.bindPopup(renderPopup(layerConfig, feature), layerConfig.popupSettings ? { className: "popup-layer-" + layerConfig.id } : {});
        }
      }
      if (featureLayer.unbindTooltip && layerConfig.label) {
        featureLayer.unbindTooltip();
        if (layerConfig.label.enabled && layerConfig.label.field) {
          var labelValue = feature.properties && feature.properties[layerConfig.label.field];
          if (labelValue != null && labelValue !== "") {
            featureLayer.bindTooltip(renderLabel(layerConfig, feature), {
              permanent: Boolean(layerConfig.label.permanent),
              offset: window.L.point(layerConfig.label.offset || [0, 0]),
              className: "q2ws-label " + (layerConfig.label.className || "")
            });
          }
        }
      }
    });
  }

  function renderLabel(layerConfig, feature) {
    var label = layerConfig.label || {};
    if (label.htmlTemplate) {
      return sanitizeLabelHtml(String(label.htmlTemplate || "").replace(/\{\{\s*([A-Za-z0-9_:-]+)\s*\}\}/g, function (_match, key) {
        return escapeHtml(feature.properties && feature.properties[key]);
      }));
    }
    var labelValue = feature.properties && feature.properties[label.field];
    return escapeHtml(labelValue);
  }

  function renderPopup(layerConfig, feature) {
    var template = layerConfig.popupTemplate;
    if (template && (template.mode === "original" || template.mode === "custom")) {
      return sanitizePopupHtml(String(template.html || "").replace(/\{\{\s*([A-Za-z0-9_:-]+)\s*\}\}/g, function (_match, key) {
        return escapeHtml(feature.properties && feature.properties[key]);
      }));
    }
    var rows = (layerConfig.popupFields || []).filter(function (field) { return field.visible; }).map(function (field) {
      var value = escapeHtml(feature.properties && feature.properties[field.key]);
      return field.header
        ? '<tr><td colspan="2"><strong>' + escapeHtml(field.label) + '</strong><br>' + value + '</td></tr>'
        : '<tr><th>' + escapeHtml(field.label) + '</th><td>' + value + '</td></tr>';
    }).join("");
    return '<table class="studio-popup">' + rows + '</table>';
  }

  function sanitizeLabelHtml(html) {
    var template = document.createElement("template");
    template.innerHTML = html;
    var allowedTags = ["DIV", "SPAN", "B", "I", "EM", "STRONG", "BR"];
    var allowedAttrs = ["class", "style"];
    template.content.querySelectorAll("*").forEach(function (element) {
      if (allowedTags.indexOf(element.tagName) === -1) {
        element.replaceWith(document.createTextNode(element.textContent || ""));
        return;
      }
      Array.from(element.attributes).forEach(function (attr) {
        if (allowedAttrs.indexOf(attr.name.toLowerCase()) === -1) element.removeAttribute(attr.name);
      });
    });
    return template.innerHTML;
  }

  function sanitizePopupHtml(html) {
    var template = document.createElement("template");
    template.innerHTML = html;
    var allowedTags = ["TABLE", "TBODY", "THEAD", "TR", "TH", "TD", "STRONG", "BR", "SPAN", "DIV", "P", "B", "I", "EM"];
    var allowedAttrs = ["class", "id", "scope", "colspan", "rowspan"];
    template.content.querySelectorAll("*").forEach(function (element) {
      if (allowedTags.indexOf(element.tagName) === -1) {
        element.replaceWith(document.createTextNode(element.textContent || ""));
        return;
      }
      Array.from(element.attributes).forEach(function (attr) {
        if (allowedAttrs.indexOf(attr.name.toLowerCase()) === -1) element.removeAttribute(attr.name);
      });
    });
    return template.innerHTML;
  }

  function layerBounds(config) {
    if (!window.L || !window.map) return null;
    var bounds = null;
    (config.layers || []).forEach(function (layerConfig) {
      if (layerConfig.visible === false) return;
      var layer = window[layerConfig.layerVariable];
      if (!layer || !layer.getBounds) return;
      var layerBounds = layer.getBounds();
      if (!layerBounds || !layerBounds.isValid || !layerBounds.isValid()) return;
      bounds = bounds ? bounds.extend(layerBounds) : layerBounds;
    });
    return bounds;
  }

  function applyInitialView(config) {
    if (!window.map) return;
    var settings = config.mapSettings || {};
    var bounds = layerBounds(config);
    if (!bounds) return;
    if (settings.initialZoomMode === "fixed") {
      window.map.setView(bounds.getCenter(), Number(settings.initialZoom || 13));
      return;
    }
    window.map.fitBounds(bounds, { padding: [28, 28] });
  }

  function runtimeLegendPositionClass(placement) {
    if (placement === "floating-top-left") return "q2ws-legend-top-left";
    if (placement === "floating-top-right") return "q2ws-legend-top-right";
    if (placement === "floating-bottom-left") return "q2ws-legend-bottom-left";
    if (placement === "floating-bottom-right") return "q2ws-legend-bottom-right";
    return "";
  }

  function normalizeLayerControlSettings(config) {
    var legacySettings = config.mapSettings || {};
    var settings = config.layerControlSettings || {};
    var mode = settings.mode || legacySettings.layerControlMode || "collapsed";
    if (mode === "compact") mode = "collapsed";
    if (["collapsed", "expanded", "tree"].indexOf(mode) === -1) mode = "collapsed";
    var position = settings.position || "top-right";
    if (["top-left", "top-right", "bottom-left", "bottom-right"].indexOf(position) === -1) position = "top-right";
    return {
      mode: mode,
      position: position,
      backgroundColor: normalizeHexColor(settings.backgroundColor, "#ffffff"),
      backgroundOpacity: clampNumber(settings.backgroundOpacity, 0, 100, 92),
      textColor: normalizeHexColor(settings.textColor, "#172026"),
      textSize: clampNumber(settings.textSize, 10, 18, 13),
      borderRadius: clampNumber(settings.borderRadius, 0, 28, 12)
    };
  }

  function alphaColor(color, opacityPercent) {
    var hex = normalizeHexColor(color, "#ffffff").slice(1);
    var alpha = clampNumber(opacityPercent, 0, 100, 100) / 100;
    return "rgba(" + parseInt(hex.slice(0, 2), 16) + ", " + parseInt(hex.slice(2, 4), 16) + ", " + parseInt(hex.slice(4, 6), 16) + ", " + alpha + ")";
  }

  function normalizeHexColor(value, fallback) {
    if (typeof value !== "string") return fallback;
    var trimmed = value.trim();
    if (/^#[0-9a-fA-F]{6}$/.test(trimmed)) return trimmed;
    if (/^#[0-9a-fA-F]{3}$/.test(trimmed)) return "#" + trimmed[1] + trimmed[1] + trimmed[2] + trimmed[2] + trimmed[3] + trimmed[3];
    return fallback;
  }

  function clampNumber(value, min, max, fallback) {
    var numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.min(max, Math.max(min, numeric));
  }

  function applyLayerToggle(config) {
    if (!window.map) return;
    var controlSettings = normalizeLayerControlSettings(config);
    var mode = controlSettings.mode;
    var layers = (config.layers || []).filter(function (layerConfig) {
      return layerConfig.showInLayerControl !== false && window[layerConfig.layerVariable];
    });
    if (!layers.length) return;
    var originalControl = document.querySelector(".leaflet-control-layers");
    if (originalControl) {
      originalControl.style.display = "none";
    }
    var control = createEl("aside", { id: "q2ws-layer-control", class: "q2ws-layer-control-" + mode + " q2ws-layer-control-" + controlSettings.position });
    control.style.background = alphaColor(controlSettings.backgroundColor, controlSettings.backgroundOpacity);
    control.style.color = controlSettings.textColor;
    control.style.borderRadius = controlSettings.borderRadius + "px";
    control.style.fontSize = controlSettings.textSize + "px";
    var header = createEl("button", { type: "button", class: "q2ws-layer-control-header", "aria-expanded": mode === "collapsed" ? "false" : "true" });
    header.style.color = controlSettings.textColor;
    header.style.fontSize = controlSettings.textSize + "px";
    header.appendChild(createEl("strong", {}, "Layers"));
    control.appendChild(header);
    var content = createEl("div", { class: "q2ws-layer-control-content" });
    var rowsHost = content;
    var treeHosts = null;
    if (mode === "tree") {
      content.classList.add("q2ws-layer-control-tree");
      treeHosts = Object.create(null);
      layers.forEach(function (layerConfig) {
        var groupName = layerConfig.layerTreeGroup || "Layers";
        if (treeHosts[groupName]) return;
        var treeGroup = createEl("div", { class: "q2ws-layer-tree-group" });
        var treeToggle = createEl("button", { type: "button", class: "q2ws-layer-tree-toggle", "aria-expanded": "true" });
        treeToggle.style.color = controlSettings.textColor;
        treeToggle.style.fontSize = controlSettings.textSize + "px";
        treeToggle.appendChild(createEl("span", { class: "q2ws-layer-tree-icon" }, "-"));
        treeToggle.appendChild(createEl("strong", {}, groupName));
        var treeItems = createEl("div", { class: "q2ws-layer-tree-items" });
        treeToggle.onclick = function () {
          treeItems.hidden = !treeItems.hidden;
          treeToggle.setAttribute("aria-expanded", treeItems.hidden ? "false" : "true");
          treeToggle.firstChild.textContent = treeItems.hidden ? "+" : "-";
        };
        treeGroup.appendChild(treeToggle);
        treeGroup.appendChild(treeItems);
        content.appendChild(treeGroup);
        treeHosts[groupName] = treeItems;
      });
    }
    layers.forEach(function (layerConfig) {
      var row = createEl("label", {});
      row.style.color = controlSettings.textColor;
      row.style.fontSize = controlSettings.textSize + "px";
      var input = createEl("input", { type: "checkbox" });
      input.checked = layerConfig.visible !== false;
      input.onchange = function () {
        var layer = window[layerConfig.layerVariable];
        if (!layer) return;
        if (input.checked) {
          window.map.addLayer(layer);
        } else {
          window.map.removeLayer(layer);
        }
      };
      row.appendChild(input);
      row.appendChild(createEl("span", {}, layerConfig.displayName || layerConfig.id));
      var groupName = layerConfig.layerTreeGroup || "Layers";
      (treeHosts && treeHosts[groupName] ? treeHosts[groupName] : rowsHost).appendChild(row);
    });
    var legendSection = buildLegendSection(config);
    if (legendSection && (config.legendSettings || {}).placement === "inside-control") {
      content.appendChild(legendSection);
    }
    if (mode === "collapsed") {
      content.hidden = true;
      header.onclick = function () {
        content.hidden = !content.hidden;
        header.setAttribute("aria-expanded", content.hidden ? "false" : "true");
      };
    }
    control.appendChild(content);
    document.body.appendChild(control);
  }

  function applyBasemap(config) {
    if (!window.L || !window.map) return;
    var selected = config.mapSettings && config.mapSettings.basemap;
    if (!selected || selected === "none") return;
    var basemaps = (config.basemaps || []).filter(function (item) { return item.enabled !== false; });
    var basemap = basemaps.find(function (item) { return item.id === selected; }) || basemaps.find(function (item) { return item.default; }) || basemaps[0];
    if (!basemap || !basemap.url) return;
    window.map.eachLayer(function (layer) {
      if (layer && layer._url && layer._url === basemap.url) return;
      if (layer && layer._url && !layer.feature) window.map.removeLayer(layer);
    });
    window.L.tileLayer(basemap.url, { attribution: basemap.attribution || "", maxZoom: basemap.maxZoom || 20 }).addTo(window.map);
  }

  function applyDisabledWidgets(config) {
    var widgets = (config.runtime && config.runtime.widgets) || [];
    widgets.forEach(function (widget) {
      if (widget.enabled !== false) return;
      if (widget.id === "measure") {
        removeControlCandidate(window.measureControl);
        removeElements(".leaflet-control-measure, .leaflet-measure-resultpopup");
        return;
      }
      if (widget.id === "photon") {
        removeControlCandidate(window.photonControl);
        removeElements(".leaflet-control-photon, .leaflet-photon, .photon-autocomplete");
        return;
      }
      if (widget.id === "layersTree") {
        removeElements(".leaflet-control-layers");
        return;
      }
      if (widget.id === "scale") {
        removeElements(".leaflet-control-scale");
        return;
      }
      if (widget.id === "fullscreen") {
        removeElements(".leaflet-control-fullscreen");
        return;
      }
      if (widget.id === "hash") {
        removeHashControl();
        return;
      }
      if (widget.id === "labels") {
        disableLabels(config);
        return;
      }
      if (widget.id === "highlight") {
        clearHighlightState(config);
        return;
      }
      if (widget.id === "pattern" || widget.id === "rotatedMarker") {
        return;
      }
      console.warn("qgis2web Studio cannot disable this preserved widget automatically:", widget.id);
    });
  }

  function removeControlCandidate(control) {
    if (!control) return;
    try {
      if (window.map && window.map.removeControl && control.remove) {
        control.remove();
        return;
      }
      if (window.map && window.map.removeControl) {
        window.map.removeControl(control);
      }
    } catch (error) {
      console.warn("qgis2web Studio failed to remove widget control", error);
    }
  }

  function removeElements(selector) {
    document.querySelectorAll(selector).forEach(function (element) {
      element.remove();
    });
  }

  function removeHashControl() {
    var hashControl = window.hash;
    if (hashControl && typeof hashControl.remove === "function") {
      hashControl.remove();
    }
    if (window.history && window.location.hash) {
      window.history.replaceState(null, document.title, window.location.pathname + window.location.search);
    }
  }

  function disableLabels(config) {
    removeElements(".q2ws-label, .leaflet-tooltip");
    (config.layers || []).forEach(function (layerConfig) {
      var layer = window[layerConfig.layerVariable];
      if (!layer || !layer.eachLayer) return;
      layer.eachLayer(function (featureLayer) {
        if (featureLayer.unbindTooltip) featureLayer.unbindTooltip();
      });
    });
  }

  function clearHighlightState(config) {
    if (!window.L) return;
    (config.layers || []).forEach(function (layerConfig) {
      var layer = window[layerConfig.layerVariable];
      if (!layer || !layer.eachLayer) return;
      layer.eachLayer(function (featureLayer) {
        if (featureLayer.setStyle && featureLayer.feature) {
          featureLayer.setStyle(styleFor(layerConfig, featureLayer.feature));
        }
      });
    });
  }

  function applySidebar(config) {
    var sidebar = config.sidebar || {};
    if (!sidebar.enabled) return;
    document.body.classList.add("q2ws-has-sidebar", "q2ws-has-sidebar-" + (sidebar.side || "right"));
    var panel = createEl("aside", { id: "q2ws-sidebar", class: "q2ws-sidebar-" + (sidebar.side || "right") });
    panel.style.width = Math.max(260, Math.min(520, Number(sidebar.width || 360))) + "px";
    panel.innerHTML = renderMarkdown(sidebar.content || "");
    document.body.appendChild(panel);
  }

  function renderMarkdown(markdown) {
    var lines = String(markdown || "").replace(/\r\n/g, "\n").split("\n");
    var html = [];
    var listType = "";
    var paragraph = [];
    function flushParagraph() {
      if (paragraph.length) {
        html.push("<p>" + inlineMarkdown(paragraph.join(" ")) + "</p>");
        paragraph = [];
      }
    }
    function closeList() {
      if (listType) {
        html.push("</" + listType + ">");
        listType = "";
      }
    }
    function openList(type) {
      if (listType === type) return;
      closeList();
      html.push("<" + type + ">");
      listType = type;
    }
    lines.forEach(function (line) {
      var trimmed = line.trim();
      if (!trimmed) {
        flushParagraph();
        closeList();
        return;
      }
      var heading = trimmed.match(/^(#{1,6})\s+(.+)$/);
      if (heading) {
        flushParagraph();
        closeList();
        html.push("<h" + heading[1].length + ">" + inlineMarkdown(heading[2]) + "</h" + heading[1].length + ">");
        return;
      }
      var blockquote = trimmed.match(/^>\s+(.+)$/);
      if (blockquote) {
        flushParagraph();
        closeList();
        html.push("<blockquote>" + inlineMarkdown(blockquote[1]) + "</blockquote>");
        return;
      }
      var unorderedListItem = trimmed.match(/^(?:[-*])\s+(.+)$/);
      if (unorderedListItem) {
        flushParagraph();
        openList("ul");
        html.push("<li>" + inlineMarkdown(unorderedListItem[1]) + "</li>");
        return;
      }
      var orderedListItem = trimmed.match(/^\d+\.\s+(.+)$/);
      if (orderedListItem) {
        flushParagraph();
        openList("ol");
        html.push("<li>" + inlineMarkdown(orderedListItem[1]) + "</li>");
        return;
      }
      paragraph.push(trimmed);
    });
    flushParagraph();
    closeList();
    return html.join("");
  }

  function inlineMarkdown(value) {
    return escapeHtml(value)
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/\*([^*]+)\*/g, "<em>$1</em>")
      .replace(/\x60([^\x60]+)\x60/g, "<code>$1</code>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  }

  function applyBranding(config) {
    var branding = config.branding || {};
    if (branding.showHeader && branding.headerPlacement !== "hidden") {
      document.body.classList.add("q2ws-has-header", "q2ws-has-header-" + (branding.headerPlacement || "top-full"));
      var header = createEl("div", { id: "q2ws-header" });
      header.className = "q2ws-header-" + (branding.headerPlacement || "top-full") + " q2ws-logo-" + (branding.logoPlacement || "left");
      var logo = branding.logoPath && branding.logoPlacement !== "hidden"
        ? '<img src="' + escapeHtml(branding.logoPath) + '" alt="">'
        : "";
      header.innerHTML = logo + "<div><strong>" + escapeHtml(branding.title || "WebGIS") + "</strong><span>" + escapeHtml(branding.subtitle || "") + "</span></div>";
      document.body.insertBefore(header, document.body.firstChild);
    }
    if (branding.showFooter && branding.footerPlacement !== "hidden") {
      var footer = createEl("div", { id: "q2ws-footer", class: "q2ws-footer-" + (branding.footerPlacement || "bottom-full") }, branding.footer || "");
      document.body.appendChild(footer);
    }
    var welcomeConfig = branding.welcome || {};
    if ((branding.showWelcome || welcomeConfig.enabled) && welcomeConfig.enabled !== false) {
      var storageKey = "q2ws-welcome-seen-" + (branding.title || "map");
      if (welcomeConfig.showOnce && localStorage.getItem(storageKey)) return;
      var welcome = createEl("div", { id: "q2ws-welcome", class: "q2ws-welcome-" + (welcomeConfig.placement || "center") });
      welcome.innerHTML = '<div><h2>' + escapeHtml(welcomeConfig.title || branding.title || "WebGIS") + '</h2><div class="q2ws-welcome-content">' + renderMarkdown(welcomeConfig.subtitle || branding.subtitle || "") + '</div><button type="button">' + escapeHtml(welcomeConfig.ctaLabel || "Mulai jelajah") + '</button></div>';
      var dismiss = function () {
        if (welcomeConfig.showOnce) localStorage.setItem(storageKey, "1");
        welcome.remove();
      };
      welcome.querySelector("button").onclick = dismiss;
      document.body.appendChild(welcome);
      if (welcomeConfig.autoDismiss && welcomeConfig.autoDismiss !== "never") {
        setTimeout(dismiss, Number(welcomeConfig.autoDismiss) * 1000);
      }
    }
  }

  function buildLegendSection(config) {
    var settings = config.legendSettings || {};
    if (settings.enabled === false || settings.placement === "hidden") return null;
    var groups = config.legendGroups && config.legendGroups.length
      ? config.legendGroups
      : [{ id: "all", label: "Layers", items: config.legend || [] }];
    if (!groups.length) return null;
    var legend = createEl("aside", { class: "q2ws-legend-section" });
    var button = createEl("button", { type: "button", class: "q2ws-legend-toggle", "aria-expanded": settings.collapsed ? "false" : "true" });
    button.appendChild(createEl("span", {}, settings.collapsed ? "+" : "-"));
    button.appendChild(createEl("strong", {}, "Legenda"));
    legend.appendChild(button);
    var content = createEl("div", { class: "q2ws-legend-content" });
    groups.forEach(function (group) {
      var visibleItems = (group.items || []).filter(function (item) { return item.visible !== false; });
      if (!visibleItems.length) return;
      var section = createEl("section", { class: "q2ws-legend-group" });
      if (settings.groupByLayer !== false) {
        section.appendChild(createEl("h4", {}, group.label || "Layer"));
      }
      visibleItems.forEach(function (item) {
        var row = createEl("div", { class: "q2ws-legend-row" });
        var swatch = createEl("span", { class: "q2ws-swatch q2ws-symbol-" + (item.symbolType || "polygon") });
        swatch.style.background = item.symbolType === "line" ? "transparent" : item.fillColor || "transparent";
        swatch.style.borderColor = item.strokeColor || item.fillColor || "#333";
        if (item.symbolType === "line") {
          swatch.style.borderTopWidth = Math.max(2, item.strokeWidth || 2) + "px";
        }
        if (item.dashArray) {
          swatch.style.borderStyle = "dashed";
        }
        row.appendChild(swatch);
        row.appendChild(createEl("span", {}, item.label));
        section.appendChild(row);
      });
      content.appendChild(section);
    });
    legend.appendChild(content);
    if (settings.collapsed) {
      legend.classList.add("q2ws-legend-collapsed");
      content.hidden = true;
    }
    button.onclick = function () {
      var collapsed = legend.classList.toggle("q2ws-legend-collapsed");
      content.hidden = collapsed;
      button.setAttribute("aria-expanded", collapsed ? "false" : "true");
      button.firstChild.textContent = collapsed ? "+" : "-";
    };
    return legend;
  }

  function applyLegend(config) {
    var settings = config.legendSettings || {};
    var positionClass = runtimeLegendPositionClass(settings.placement);
    if (!positionClass) return;
    var legend = buildLegendSection(config);
    if (!legend) return;
    legend.id = "q2ws-legend";
    legend.classList.add(positionClass);
    document.body.appendChild(legend);
  }

  function applyTextAnnotations(config) {
    if (!window.L || !window.map) return;
    (config.textAnnotations || []).forEach(function (feature) {
      if (!feature.geometry || feature.geometry.type !== "Point") return;
      var coords = feature.geometry.coordinates;
      var props = feature.properties || {};
      var icon = window.L.divIcon({
        className: "q2ws-text-label",
        html: '<span style="color:' + (props.color || "#172026") + ';font-size:' + (props.fontSize || 13) + 'px">' + escapeHtml(props.text || "") + "</span>"
      });
      window.L.marker([coords[1], coords[0]], { icon: icon }).addTo(window.map);
    });
  }

  function applyLabelCss(config) {
    var css = (config.layers || []).map(function (layerConfig) {
      var label = layerConfig.label || {};
      if (!label.className || !label.cssText) return "";
      return "." + label.className + " { " + label.cssText + " }";
    }).filter(Boolean).join("\n");
    if (!css) return;
    var style = document.getElementById("q2ws-label-css");
    if (!style) {
      style = createEl("style", { id: "q2ws-label-css" });
      document.head.appendChild(style);
    }
    style.textContent = css;
  }

  function applyPopupStyle(config) {
    var popup = config.popupSettings || {};
    var accent = popup.accentColor || "#156f7a";
    var background = popup.backgroundColor || "#ffffff";
    var text = popup.textColor || "#172026";
    var label = popup.labelColor || "#4b5b66";
    var radius = Number(popup.radius == null ? 10 : popup.radius);
    var shadow = Number(popup.shadow == null ? 22 : popup.shadow);
    var style = popup.style || "card";
    var border = style === "minimal" ? "0" : "1px solid " + accent;
    var padding = style === "compact" ? "5px 7px" : "7px 9px";
    var css = [
      ".leaflet-popup-content-wrapper{border:" + border + ";border-radius:" + radius + "px;background:" + background + ";color:" + text + ";box-shadow:0 " + Math.max(6, shadow / 2) + "px " + Math.max(14, shadow) + "px rgba(0,0,0,.22);}",
      ".leaflet-popup-tip{background:" + background + ";box-shadow:0 8px 18px rgba(0,0,0,.16);}",
      ".leaflet-popup-content{max-width:min(360px,72vw);margin:12px 14px;overflow-wrap:anywhere;line-height:1.42;}",
      ".studio-popup{width:100%;min-width:220px;max-width:340px;table-layout:fixed;border-collapse:separate;border-spacing:0;font:12px Inter,Segoe UI,Arial,sans-serif;}",
      ".studio-popup th,.studio-popup td{border:1px solid rgba(82,103,113,.14);padding:" + padding + ";vertical-align:top;white-space:normal;overflow-wrap:anywhere;word-break:break-word;line-height:1.36;}",
      ".studio-popup th{width:38%;background:" + rgbaFromHex(accent, style === "compact" ? 0 : 0.09) + ";color:" + label + ";font-weight:750;text-align:left;}",
      ".studio-popup strong{color:" + accent + ";}"
    ].join("");
    var styleEl = createEl("style", { id: "q2ws-popup-style" }, css);
    document.head.appendChild(styleEl);
    (config.layers || []).forEach(function (layerConfig) {
      if (!layerConfig.popupSettings) return;
      var override = layerConfig.popupSettings;
      var layerCss = ".popup-layer-" + layerConfig.id + " .leaflet-popup-content-wrapper{border-color:" + (override.accentColor || accent) + ";border-radius:" + (override.radius || radius) + "px;background:" + (override.backgroundColor || background) + ";color:" + (override.textColor || text) + ";box-shadow:0 " + Math.max(6, Number((override.shadow == null ? shadow : override.shadow)) / 2) + "px " + Math.max(14, Number(override.shadow == null ? shadow : override.shadow)) + "px rgba(0,0,0,.22);}" +
        ".popup-layer-" + layerConfig.id + " .leaflet-popup-tip{background:" + (override.backgroundColor || background) + ";}" +
        ".popup-layer-" + layerConfig.id + " .studio-popup th{color:" + (override.labelColor || label) + ";}" +
        ".popup-layer-" + layerConfig.id + " .studio-popup strong{color:" + (override.accentColor || accent) + ";}";
      document.head.appendChild(createEl("style", {}, layerCss));
    });
  }

  function rgbaFromHex(hex, opacity) {
    var value = String(hex || "").replace("#", "");
    if (value.length === 3) {
      value = value.split("").map(function (char) { return char + char; }).join("");
    }
    if (value.length !== 6) return "transparent";
    var r = parseInt(value.slice(0, 2), 16);
    var g = parseInt(value.slice(2, 4), 16);
    var b = parseInt(value.slice(4, 6), 16);
    if ([r, g, b].some(function (channel) { return Number.isNaN(channel); })) return "transparent";
    return "rgba(" + r + "," + g + "," + b + "," + opacity + ")";
  }

  function escapeHtml(value) {
    return String(value || "").replace(/[&<>"']/g, function (char) {
      return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char];
    });
  }

  function showRuntimeError(error) {
    var message = error && error.message ? error.message : "Unknown runtime error.";
    var panel = createEl("div", { id: "q2ws-runtime-error", role: "alert" });
    panel.innerHTML = "<strong>Studio runtime failed to initialize.</strong><span>Check q2ws-config.json and the browser console.</span><code>" + escapeHtml(message) + "</code>";
    document.body.appendChild(panel);
  }

  ready(function () {
    fetch("q2ws-config.json")
      .then(function (response) { return response.json(); })
      .then(function (config) {
        document.documentElement.style.setProperty("--q2ws-accent", config.theme.accent);
        document.documentElement.style.setProperty("--q2ws-surface", config.theme.surface);
        document.documentElement.style.setProperty("--q2ws-text", config.theme.text);
        document.documentElement.style.setProperty("--q2ws-radius", config.theme.radius + "px");
        document.documentElement.style.setProperty("--q2ws-header-height", (config.theme.headerHeight || 48) + "px");
        applyBasemap(config);
        applyBranding(config);
        applySidebar(config);
        applyLabelCss(config);
        applyLayerConfig(config);
        applyInitialView(config);
        applyLayerToggle(config);
        applyDisabledWidgets(config);
        applyPopupStyle(config);
        applyLegend(config);
        applyTextAnnotations(config);
      })
      .catch(function (error) {
        console.warn("qgis2web Studio runtime failed", error);
        showRuntimeError(error);
      });
  });
})();